package com.cg.hdfca.service;
/*
 * @author Aditya Sinha
 * @version 1.0
 * 
 */
import java.util.List;

import com.cg.hdfca.bean.Transaction;
import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.dao.WalletDao;
import com.cg.hdfca.dao.WalletJpaDao;
import com.cg.hdfca.exception.CustomerExists;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.exception.IllegalFormatException;
import com.cg.hdfca.exception.InsufficientBalanceException;

public class WalletServiceImpl implements WalletService {

	//object instantiation 
	WalletDao walletDAO = new WalletJpaDao();

	//withdraw amount
	//minimum balance should be 100
	@Override
	public String withDraw(Wallet wallet, double amount) throws InsufficientBalanceException{
		try {
			walletDAO.beginTransaction();
			String result = walletDAO.withDraw(wallet, amount);
			walletDAO.commitTransaction();
			return result;
		} catch (InsufficientBalanceException e) {
			walletDAO.commitTransaction();
			throw new InsufficientBalanceException(e.getMessage());
		}
	}

	//deposit amount in wallet
	@Override
	public String deposit(Wallet wallet, double amount) throws CustomerNotFoundException{
		try {
			walletDAO.beginTransaction();
			String result = walletDAO.deposit(wallet, amount);
			walletDAO.commitTransaction();
			return result;
		} catch (Exception e) {
			walletDAO.commitTransaction();
			throw new CustomerNotFoundException(e.getMessage());
		}
	}

	//store withdraw result and deposit result in array
	@Override
	public String[] fundTransfer(Wallet fromCust, Wallet toCust, double amount) throws InsufficientBalanceException, CustomerNotFoundException {
		
		String[] result = new String[2];
		try
		{
			walletDAO.beginTransaction();
			result[0] = walletDAO.withDraw(fromCust, amount);
			result[1] = walletDAO.deposit(toCust, amount);
			walletDAO.commitTransaction();
			return result;
		}catch(InsufficientBalanceException e)
		{
			walletDAO.commitTransaction();
			throw new InsufficientBalanceException(e.getMessage());
		}
		catch(CustomerNotFoundException e)
		{
			walletDAO.commitTransaction();
			//if wrong mobile number
			throw new CustomerNotFoundException(e.getMessage());
		}
	
		
	}

	//returns records in list
	@Override
	public List<Transaction> printTransaction(Wallet wallet) {
		return walletDAO.printTransaction(wallet);
	}

	//create user
	@Override
	public Wallet createCustomer(Wallet wallet) throws CustomerExists{
		try {
			walletDAO.beginTransaction();
			Wallet customerWithId = walletDAO.createCustomer(wallet);
			walletDAO.commitTransaction();
			return customerWithId;
		} catch (CustomerExists e) {
			walletDAO.commitTransaction();
			throw new CustomerExists(e.getMessage());
		}
	}

	//login method
	@Override
	public Wallet checkUser(String username, String password) throws CustomerNotFoundException{
		try {
			walletDAO.beginTransaction();
			Wallet wallet = walletDAO.checkUser(username, password);
			walletDAO.commitTransaction();
			return wallet;
		} catch (CustomerNotFoundException e) {
			walletDAO.commitTransaction();
			throw new CustomerNotFoundException(e.getMessage());
		}
	}
	
	@Override
	public double checkBalance(Wallet wallet) {
		return walletDAO.checkBalance(wallet);
	}

	
	//-------validation codes below------------//
	@Override
	public boolean validateName(String name) throws IllegalFormatException{
		if(name.matches(userNamePattern))
			return true;
		else
			throw new IllegalFormatException("name should be between 2 - 9 letters with 1st letter capital");
	}

	@Override
	public boolean validateMobNo(String mobileno)  throws IllegalFormatException{
		if(mobileno.matches(usermobilePattern))
			return true;
		else
			throw new IllegalFormatException("Enter Valid 10 digit mobile number.");
	}

	@Override
	public boolean validateEmail(String email)  throws IllegalFormatException{
		if(email.matches(useremailPattern))
			return true;
		else
			throw new IllegalFormatException("Enter Valid Email");
	}

	@Override
	public boolean validatePassword(String password)  throws IllegalFormatException{
		if(password.matches(userpasswordPattern))
			return true;
		else
			throw new IllegalFormatException("Enter atleast 6-12 character");
	}

	@Override
	public boolean validateHomeChoice(String userHChoice)  throws IllegalFormatException{
		if(userHChoice.matches(userHomeChoice))
			return true;
		else
			throw new IllegalFormatException("Please choose 1 or 2 or 3");
	}

	@Override
	public boolean validateAmount(String useramt)  throws IllegalFormatException{
		if(useramt.matches(userAmount))
			return true;
		else
			throw new IllegalFormatException("Enter in numbers and should be more than Rs.10");
	}

	@Override
	public boolean validateMenuChoice(String userMChoice)
			throws IllegalFormatException {
		if(userMChoice.matches(userMenuChoice))
			return true;
		else
			throw new IllegalFormatException("Please choose between 1 - 6");
	}

	@Override
	public Wallet isValidUser(String mobileNumber)
			throws CustomerNotFoundException {
		try
		{
			return walletDAO.isValidUser(mobileNumber);			
		}catch(CustomerNotFoundException e)
		{
			throw new CustomerNotFoundException(e.getMessage());
		}

	}
}
