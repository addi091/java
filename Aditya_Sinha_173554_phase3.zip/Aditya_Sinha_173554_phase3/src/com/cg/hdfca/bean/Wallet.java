package com.cg.hdfca.bean;
/*
 * @author Aditya Sinha
 * @version 1.0
 * 
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "wallet")
public class Wallet {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customerId")
	@SequenceGenerator(sequenceName = "cust_seq", name = "customerId")
	private long customerId;
	private String name;
	private String email;
	private String mobileNumber;
	private String password;
	private double balance;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getCustomerId() {
		return customerId;
	}

	public Wallet() {
		super();
	}

	public Wallet(String name, String email, String mobileNumber,
			String password, double balance) {
		super();
		this.name = name;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.password = password;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [customerId=" + customerId + ", name=" + name
				+ ", email=" + email + ", mobileNumber=" + mobileNumber
				+ ", password=" + password + ", balance=" + balance + "]";
	}
	
}
