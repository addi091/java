package com.cg.hdfca.ui;
/*
 * @author Aditya Sinha
 * @version 1.0
 * 
 */
import java.util.List;
import java.util.Scanner;

import com.cg.hdfca.bean.Transaction;
import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.config.JPAConfig;
import com.cg.hdfca.exception.CustomerExists;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.exception.IllegalFormatException;
import com.cg.hdfca.exception.InsufficientBalanceException;
import com.cg.hdfca.service.WalletService;
import com.cg.hdfca.service.WalletServiceImpl;

public class WalletUI {

	public static void main(String[] args) {
		
		// object instantiation
		Wallet newCust = new Wallet();
		Wallet loggedCust = new Wallet();
		
		System.out.println("Establishing Connection.....");
		
		WalletService service = new WalletServiceImpl();
		
		System.out.println("Connection Established..!!");
		Scanner scan = new Scanner(System.in);

		// Asks for Inputs
		for (;;) {
			System.out.println("Welcome to HDFCA Wallet\n1) Register\n2) Login \n3) Exit");
			String homeChoice = "";

			while (true) {
				homeChoice = scan.next();
				try {
					//validate if input between 1-3
					if (service.validateHomeChoice(homeChoice))
						break;
				} catch (IllegalFormatException e) {
					System.out.println(e.getMessage());
				}
			}

			if (homeChoice.equals("1"))// register code
			{
				while (true)// take name
				{
					System.out.println("Enter name with first letter in Capital");
					String temp = scan.next();
					try {
						//validate name
						if (service.validateName(temp)) {
							newCust.setName(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take email
				{
					System.out.println("Enter email Id");
					String temp = scan.next();
					try {
						//validate email
						if (service.validateEmail(temp)) {
							newCust.setEmail(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take mobile
				{
					System.out.println("Enter Mobile No");
					String temp = scan.next();
					try {
						//validate mobile number
						if (service.validateMobNo(temp)) {
							newCust.setMobileNumber(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}
				while (true)// set password
				{
					System.out.println("Set Password");
					String temp = scan.next();
					try {
						//validate password
						if (service.validatePassword(temp)) {
							newCust.setPassword(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				// set balance
				newCust.setBalance(5000);

				// try to create new user and also checks if user exists
				try {
					Wallet cust = service.createCustomer(newCust);
					System.out.println("***New Customer Created***");
					System.out.println(cust);
				} catch (CustomerExists e) {
					System.out.println(e.getMessage());
				}

			}// end of register
			
			else if (homeChoice.equals("2"))// login code
			{
				while (true) {
					System.out.println("Enter Mobile no");
					String temp = scan.next();
					System.out.println("Enter Password");
					String pass = scan.next();
					try {
						//get customer from login
						loggedCust = service.checkUser(temp, pass);
						break;
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// start submenu
				{
					System.out.println("Welcome "+loggedCust.getName());
					System.out.println("1) Show Balance");
					System.out.println("2) Deposit");
					System.out.println("3) Withdraw");
					System.out.println("4) Fund Transfer");
					System.out.println("5) Print Transactions");
					System.out.println("6) Logout");
					String choice = "";
					boolean isLogOut = false;

					while(true)
					{
						choice = scan.next();
					try {
						//validate if input between 1-6
						if (service.validateMenuChoice(choice))
							break;
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
					}
					
					switch (choice) {
					case "1":
						System.out.println("Balance is Rs."+ service.checkBalance(loggedCust));
						break;

					case "2":
						while (true) {
							System.out.println("Enter amount to deposit");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}

						String depositResult="";
						try {
							depositResult = service.deposit(loggedCust,
							Double.parseDouble(choice));
						} catch (NumberFormatException e1) {
								System.out.println(e1.getMessage());
						} catch (CustomerNotFoundException e1) {
							System.out.println(e1.getMessage());
						}
						//print the result from server
						System.out.println(depositResult);
						break;

					case "3":
						while (true) {
							System.out.println("Enter amount to withdraw");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}//end of while loop

						try {
							String withdrawResult = service.withDraw(
									loggedCust,
									Double.parseDouble(choice));
							System.out.println(withdrawResult);
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "4":
						
						String mob="";
						String amt="";
						Wallet reciever = null;
						while(true)
						{
							System.out.println("Enter mobile number of other user");
							 mob = scan.next();
							System.out.println("Enter the amount");
							 amt = scan.next();
							
							try {
								if(service.validateMobNo(mob) && service.validateAmount(amt))
								{
									reciever = service.isValidUser(mob);
									break;
								}
									
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}catch (CustomerNotFoundException e) {
								System.out.println(e.getMessage());
							}						
						}

						//store the fund transfer results
						try {
							String[] data = service.fundTransfer(
									loggedCust, reciever,
									Double.parseDouble(amt));
							for (String result : data) {
								System.out.println(result);
							}
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						} catch (CustomerNotFoundException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "5":
						List<Transaction> list = 
							service.printTransaction(loggedCust);
						System.out.println(list);
						break;

					case "6":
						//logout the user
						JPAConfig.closeManager();
						isLogOut = true;
					default:
						break;
					}

					if (isLogOut) {
						isLogOut = false;
						break;
					} else
						continue;
				}
			}// end of login code
			else { //if choice is 3 ie exit
					JPAConfig.closeManager();
					System.out.println("Exited Successfully. Please Visit Again Thank You! ");
					break;
			}
		}// end of eternal loop
	}
}
