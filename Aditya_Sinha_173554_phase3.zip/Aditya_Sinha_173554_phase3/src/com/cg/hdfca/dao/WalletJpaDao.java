package com.cg.hdfca.dao;
/*
 * @author Aditya Sinha
 * @version 1.0
 * 
 */
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.hdfca.bean.Transaction;
import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.config.JPAConfig;
import com.cg.hdfca.exception.CustomerExists;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.exception.InsufficientBalanceException;

public class WalletJpaDao implements WalletDao {

	 EntityManager manager = JPAConfig.getEntityManager();

	public WalletJpaDao() {
		manager = JPAConfig.getEntityManager();
	}

	public void beginTransaction() {
		manager.getTransaction().begin();
	}

	public void commitTransaction()	{
		manager.getTransaction().commit();
	}
	

	@Override
	public Wallet createCustomer(Wallet wallet) throws CustomerExists {
		TypedQuery<Long> query = manager.createQuery("SELECT COUNT(wallet.customerId) FROM Wallet wallet where wallet.mobileNumber=:pMob",Long.class);
		query.setParameter("pMob", wallet.getMobileNumber());
		long count = query.getSingleResult();
		
		if(count<1)
		{
			manager.persist(wallet);
			Transaction log = new Transaction(wallet.getMobileNumber(), "CR",
					wallet.getBalance(), wallet.getBalance());
			manager.persist(log);
			return wallet;	
		}
		else
		{
			throw new CustomerExists("Customer Already Exists");
		}
	}

	@Override
	public String withDraw(Wallet wallet, double amount)
			throws InsufficientBalanceException {
		if (amount <= wallet.getBalance() - 100)
		{
			wallet.setBalance(wallet.getBalance()-amount);
			
			Transaction log = new Transaction(
					wallet.getMobileNumber(),
					"DB",
					amount,
					wallet.getBalance()
					);
			
			manager.persist(log);
			return "Rs." + amount + " debited from account "
			+ wallet.getCustomerId() + " on "
			+ LocalDateTime.now() + "\nNew Balance is Rs."
			+ wallet.getBalance();
		}
		else
		{
			throw new InsufficientBalanceException("You Have Insufficient Fund.");
		}
	}

	@Override
	public String deposit(Wallet wallet, double amount)
			throws CustomerNotFoundException {
		
		wallet.setBalance(wallet.getBalance() + amount);
		Transaction log = new Transaction(
				wallet.getMobileNumber(),
				"CR",
				amount,
				wallet.getBalance()
				);
		
		manager.persist(log);
		return "Rs." + amount + " credited on account "
				+ wallet.getCustomerId() + " on " + LocalDateTime.now()
				+ "\nNew Balance is Rs." + wallet.getBalance();
	}

	@Override
	public Wallet checkUser(String username, String password)	throws CustomerNotFoundException {
		TypedQuery<Wallet> query = manager.createQuery(
						"Select wallet FROM Wallet wallet WHERE wallet.mobileNumber=:pMob AND wallet.password=:pPass",
						Wallet.class);
		query.setParameter("pMob", username);
		query.setParameter("pPass", password);
		if(query.getResultList().size()!=0)
		{
			Wallet wallet = query.getSingleResult();
			return wallet;
		}
		else
		{
			throw new CustomerNotFoundException("Invalid Credentials");
		}
	}

	@Override
	public List<Transaction> printTransaction(Wallet wallet) {
		Query query = manager
				.createQuery(
						"SELECT tran FROM TransactionData tran WHERE tran.mobileNo=:pMob",
						Transaction.class);
		query.setParameter("pMob", wallet.getMobileNumber());
		List<Transaction> list = query.getResultList();
		return list;
	}

	@Override
	public Wallet isValidUser(String mobileNumber)
			throws CustomerNotFoundException {
		
		TypedQuery<Wallet> query = manager.createQuery("SELECT wallet FROM Wallet wallet WHERE wallet.mobileNumber=:pMob",Wallet.class);
		query.setParameter("pMob", mobileNumber);
		if(query.getResultList().size()!=0)
		{
			Wallet wallet = query.getSingleResult();
			return wallet;
		}
		else
		{
			throw new CustomerNotFoundException("No User Found With Given Mobile Number");
		}
	}

	@Override
	public double checkBalance(Wallet wallet) {
		return wallet.getBalance();
	}

}