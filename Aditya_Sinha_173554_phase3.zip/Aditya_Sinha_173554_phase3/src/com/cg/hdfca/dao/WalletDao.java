package com.cg.hdfca.dao;
/*
 * @author Aditya Sinha
 * @version 1.0
 * 
 */
import java.util.List;

import com.cg.hdfca.bean.Transaction;
import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.exception.CustomerExists;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.exception.InsufficientBalanceException;

public interface WalletDao {

	Wallet createCustomer(Wallet wallet) throws CustomerExists;

	String withDraw(Wallet wallet, double amount)	throws InsufficientBalanceException;

	String deposit(Wallet wallet, double amount) throws CustomerNotFoundException;

	Wallet checkUser(String username, String password) throws CustomerNotFoundException;

	List<Transaction> printTransaction(Wallet wallet);

	Wallet isValidUser(String mobileNumber) throws CustomerNotFoundException;
	
	double checkBalance(Wallet wallet);

	void beginTransaction();
	void commitTransaction();
}
