package com.cg.hdfca.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.service.WalletService;
import com.cg.hdfca.service.WalletServiceImpl;

public class DepositTest {

	WalletService service = null;

	@Before
	public void setUp() throws Exception {
		service = new WalletServiceImpl();
	}

	// right inputs
	@Test
	public void checkDeposit() {
		try {
			Wallet wallet = service.checkUser("8286703935", "password");
			String result = service.deposit(wallet, 2000);
			System.out.println(result);
			Assert.assertEquals(7000, wallet.getBalance(),0);
		}catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() {
		try {
			Wallet wallet = service.checkUser("11111935", "password");
			String result = service.deposit(wallet, 9000);
			System.out.println(result);
			assertNotNull(result);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
