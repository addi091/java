package com.cg.hdfca.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.exception.InsufficientBalanceException;
import com.cg.hdfca.service.WalletService;
import com.cg.hdfca.service.WalletServiceImpl;

public class FundTransferTest {

	WalletService service = null;

	@Before
	public void setUp() throws Exception {
		service = new WalletServiceImpl();
	}

	// right inputs
	@Test
	public void checkFundTransfer() {
		try {
			Wallet wallet = service.checkUser("8286703935", "password");
			Wallet wallet2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(wallet,wallet2, 1000);
			for (String r : result) 
				System.out.println(r);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkFundTransfer2() {
		try {
			Wallet wallet = service.checkUser("8286703935", "password");
			Wallet wallet2 = service.isValidUser("9892622745");
			String[] result = service.fundTransfer(wallet,wallet2, 900000);
			assertNotNull(result);
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	//wrong inputs
	//should give no user found
	@Test
	public void checkFundTransfer3() {
		try {
			Wallet wallet = service.checkUser("8286703935", "password");
			Wallet wallet2 = service.isValidUser("111112745");
			String[] result = service.fundTransfer(wallet,wallet2, 2000);
			assertNotNull(result);
		}catch (CustomerNotFoundException e) {
				System.out.println(e.getMessage()); 
		}catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@After
	public void destroy() throws Exception {
		service = null;
	}
}
