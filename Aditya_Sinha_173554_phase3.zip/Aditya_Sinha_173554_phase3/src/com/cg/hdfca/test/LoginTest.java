package com.cg.hdfca.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hdfca.bean.Wallet;
import com.cg.hdfca.exception.CustomerNotFoundException;
import com.cg.hdfca.service.WalletService;
import com.cg.hdfca.service.WalletServiceImpl;

public class LoginTest {


	WalletService service = null;

	@Before
	public void setUp() throws Exception {
		service = new WalletServiceImpl();
	}

	// right inputs
	@Test
	public void checkLogin() {
		try {
			Wallet wallet = service.checkUser("8286703935", "password");
			assertNotNull(wallet);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user in console
	@Test
	public void checkLogin2() {
		try {
			Wallet wallet1 = service.checkUser("23123123", "asdasd");
			assertNotNull(wallet1);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
